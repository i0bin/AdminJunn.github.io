---
title: eNSP路由配置（一）
abstract: 静态路由配置
date: 2019-11-4 21:03:36
tags: 
	- HCNA
categories: 
	- HCNA学习笔记
---
# 拓扑规划
4个 __AR2220 路由器__ , 2台 __PC__
![img0](/image/0031.png) 
2个PC域为__1.0.0.0/8__和__4.0.0.0/8__
按照路由器顺序:__(因为现在只需要2个地址给路由器互通,所以掩码设置为30)__ 
AR1与AR2域为__12.0.0.0/30__
AR2与AR3域为__23.0.0.0/30__
AR3与AR4域为__34.0.0.0/30__

# 接口IP配置
## PC端
设置IP地址,掩码,网关
![img1](/image/0032.png)
## 路由器
__为方便辨认路由器,先给路由器改名__
__AR1__
```vrp
<Huawei> system-view
[Huawei] sysname AR1
[AR1]
	#配置接口地址
[AR1] interface GigabitEthernet 0/0/0		#进入GE 0/0/0 接口	
[AR1-GigabitEthernet0/0/0] ip address 1.0.0.1 8		#添加IP地址
```
__ip address xx.xx.xx.xx X , xx.xx.xx.xx为十进制ip地址, X 为CIDR掩码位数__
若有一下提示
Nov  4 2019 19:31:21-08:00 AR1 %%01IFNET/4/LINK_STATE(l)[0]:The line protocol IP
 on the interface GigabitEthernet0/0/0 has entered the UP state.   <===__UP state__
 即为配置成功
 若配置失败,使用 undo ip address xx.xx.xx.xx X
 ```vrp
[AR1-GigabitEthernet0/0/0] q 	#退出当前接口
[AR1] interface GigabitEthernet 0/0/1 	#进入下一个接口
```
__按照上述操作依次配好4个路由器接口__ 

配置完成后,可使用__display current-configuration__查看配置是否和规划一致
![img2](/image/0033.png)
# 静态路由配置
要实现全网连通,要让pc1 ping通每一个网段,
经过分析路由器
__AR1__ 让pc1,
从 自己 到23.0.0.0网段下一跳为 12.0.0.2 
从 自己 到34.0.0.0网段下一跳为 12.0.0.2 
从 自己 到 4.0.0.0网段下一跳为 12.0.0.2 
综上可直接设置默认路由为 
===========================>
ip route-static 0.0.0.0 0 12.0.0.2
&emsp;&emsp;&emsp;&emsp; &emsp;目的地址 掩码 下一跳
__下一跳地址为下一个路由器的入口端口ip__
![img3](/image/0034.png)
__AR2__
从 自己 到 1.0.0.0网段下一跳为 12.0.0.1 
从 自己 到34.0.0.0网段下一跳为 23.0.0.2 
从 自己 到 4.0.0.0网段下一跳为 23.0.0.2 
![img4](/image/0035.png)
__AR3__
从 自己 到 1.0.0.0网段下一跳为 23.0.0.1 
从 自己 到12.0.0.0网段下一跳为 23.0.0.1 
从 自己 到 4.0.0.0网段下一跳为 34.0.0.2 
![img5](/image/0036.png)
__AR4__
从 自己 到 1.0.0.0网段下一跳为 34.0.0.1 
从 自己 到12.0.0.0网段下一跳为 34.0.0.1 
从 自己 到23.0.0.0网段下一跳为 34.0.0.1 
综上可直接设置默认路由为 
===========================>
ip route-static 0.0.0.0 0 34.0.0.1 
![img6](/image/0037.png)
# 查看路由表
__AR1, AR2__
![img7](/image/0038.png)
__AR3, AR4__
![img8](/image/0039.png)
# 测试网络连通性
__使用PC1, ping各个网段, tracert 命令测试路由路径__
![img9](/image/0040.png)

下一篇应该是ospf, wait.........