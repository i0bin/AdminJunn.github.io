---
title: eNSP路由配置（二）
abstract: ospf配置
date: 2019-11-4 22:37:58
tags: 
	- HCNA
categories: 
	- HCNA学习笔记
---
# 规划拓扑
4个 __AR2220 路由器__ , 4台 __PC__ , 2台 __S3700 交换机__
这个规划图需要在__AR1,AR4__上各加2个"2SA"接口卡
![img-1](/image/0041.png)
__规划如图__
![img0](/image/0042.png)
# 按照规划配置各接口ip
&emsp;配置方法在上一篇中已写
__AR1__ 和 __AR4__ 的Serial接口ip与其他接口配置一样
__例:__
![img1](/image/0043.png)
# 配置ospf
__AR1__
net命令===>
&emsp;net 本路由器直连网段 通配符掩码
__[通配符掩码](https://baike.baidu.com/item/%E9%80%9A%E9%85%8D%E7%AC%A6%E6%8E%A9%E7%A0%81/9688947?fr=aladdin):__（wildcard-mask）路由器使用的通配符掩码与源或目标地址一起来分辨匹配的地址范围，它与子网掩码不同。它不像子网掩码告诉路由器IP地址的哪一位属于网络号一样，通配符掩码告诉路由器为了判断出匹配，它需要检查IP地址中的多少位.
![img9](/image/0051.png)
```C
[AR1] ospf
[AR1-ospf-1] area 0
[AR1-ospf-1-area-0.0.0.0] net 1.0.0.0 0.255.255.255
[AR1-ospf-1-area-0.0.0.0] net 12.0.0.0 0.0.0.3
[AR1-ospf-1-area-0.0.0.0] net 13.0.0.0 0.0.0.3
[AR1-ospf-1-area-0.0.0.0] net 14.0.0.0 0.0.0.3
```
![img2](/image/0044.png)
__AR2__
**以下配置中途会弹出提示消息{ospf从其他路由器学到的路由信息}(粉色框)**
```C
[AR2] ospf
[AR2-ospf-1] area 0
[AR2-ospf-1-area-0.0.0.0] net 12.0.0.0 0.0.0.3
[AR2-ospf-1-area-0.0.0.0] net 24.0.0.0 0.0.0.3
```
![img3](/image/0045.png)
__AR3__
```C
[AR3] ospf
[AR3-ospf-1] area 0
[AR3-ospf-1-area-0.0.0.0] net 13.0.0.0 0.0.0.3
[AR3-ospf-1-area-0.0.0.0] net 34.0.0.0 0.0.0.3
```
![img4](/image/0046.png)
__AR4__
```C
[AR3] ospf
[AR3-ospf-1] area 0
[AR3-ospf-1-area-0.0.0.0] net 4.0.0.0 0.255.255.255
[AR3-ospf-1-area-0.0.0.0] net 14.0.0.0 0.0.0.3
[AR3-ospf-1-area-0.0.0.0] net 24.0.0.0 0.0.0.3
[AR3-ospf-1-area-0.0.0.0] net 34.0.0.0 0.0.0.3
```
![img5](/image/0047.png)
# 查看ospf路由
__这里示例一个,AR2,AR3,AR4 ,查看方法都一样__
```C
[AR1] display ospf routing
```
![img6](/image/0048.png)
# 查看路由器路由表
__这里示例一个,AR2,AR3,AR4 ,查看方法都一样__
```C
[AR1] display ip routing-table
```
![img7](/image/0049.png)
# 测试全网连通性
打开PC1 , 使用ping, tracert 命令进行测试
![img8](/image/0050.png)